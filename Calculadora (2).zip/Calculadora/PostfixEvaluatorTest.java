import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PostfixEvaluatorTest {

    @Test
    void testEvaluatePostfix() {
        assertEquals(9, PostfixEvaluator.evaluatePostfix("53+2*"));
        assertEquals(14, PostfixEvaluator.evaluatePostfix("82/3-"));
        assertThrows(IllegalArgumentException.class, () -> PostfixEvaluator.evaluatePostfix("82a/3-"));
    }

    @Test
    void testIsOperator() {
        assertTrue(PostfixEvaluator.isOperator('+'));
        assertTrue(PostfixEvaluator.isOperator('-'));
        assertTrue(PostfixEvaluator.isOperator('*'));
        assertTrue(PostfixEvaluator.isOperator('/'));
        assertFalse(PostfixEvaluator.isOperator('a'));
    }

    @Test
    void testPerformOperation() {
        assertEquals(5, PostfixEvaluator.performOperation(2, 3, '+'));
        assertEquals(-1, PostfixEvaluator.performOperation(2, 3, '-'));
        assertEquals(6, PostfixEvaluator.performOperation(2, 3, '*'));
        assertEquals(2, PostfixEvaluator.performOperation(6, 3, '/'));
        assertThrows(IllegalArgumentException.class, () -> PostfixEvaluator.performOperation(2, 3, 'a'));
    }

    private void assertEquals(int i, int performOperation) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'assertEquals'");
    }
}
