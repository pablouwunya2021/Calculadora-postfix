
//Pablo Andrés Cabrera 231156
//José Sanchez 231221
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Stack;

public class PostfixEvaluator {

    public static int evaluatePostfix(String expression) {
        Stack<Integer> stack = new Stack<>();

        for (char c : expression.toCharArray()) {
            if (Character.isDigit(c)) {
                // convertir a número y hacer push en la pila
                stack.push(Character.getNumericValue(c));
            } else if (isOperator(c)) {
                //  realizar la operación correspondiente
                int operandB = stack.pop();
                int operandA = stack.pop();
                int result = performOperation(operandA, operandB, c);
                stack.push(result);
            }
        }

        // resultado final 
        return stack.pop();
    }

    public static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    public static int performOperation(int operandA, int operandB, char operator) {
        switch (operator) {
            case '+':
                return operandA + operandB;
            case '-':
                return operandA - operandB;
            case '*':
                return operandA * operandB;
            case '/':
                return operandA / operandB;
            default:
                throw new IllegalArgumentException("Operador no reconocido: " + operator);
        }
    }

    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new FileReader("datos.txt"))) {
            String expression = reader.readLine();
            int result = evaluatePostfix(expression);
            System.out.println("Resultado: " + result);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
